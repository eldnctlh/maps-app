import React, { Component, Fragment } from "react";
import '../styles/styles.less';
import RouterNavigation from './RouterNavigation';

class App extends Component {
    render() {
        return (
            <RouterNavigation />
        );
    }
}

export default App;