import { combineReducers } from 'redux';
import map from './map';

export default combineReducers({
    map
})